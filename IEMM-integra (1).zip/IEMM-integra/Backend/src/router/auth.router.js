import { Router } from "express";
import { login, registrar, me, signout } from "../controller/auth.controller.js";
import { protegerRuta } from "../middleware/auth.middleware.js";

const router = Router();

router.post("/login", login);
router.post("/registrar", registrar);
router.get("/me", protegerRuta, me);
router.post("/signout", signout);

export default router;
