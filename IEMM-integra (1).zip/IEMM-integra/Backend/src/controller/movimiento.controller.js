import { servicioLeerMovimientos } from "../service/movimiento.service.js";
import { manejarError } from "../utils/manejarError.js";

export const leerMovimientos = async (req, res) => {
    try {
        const limite = Number(req.query.limite);
        const movimientos = await servicioLeerMovimientos(Number.isInteger(limite) && limite > 0 ? limite : undefined);
        res.status(200).json(movimientos);
    } catch (error) {
        manejarError(res, error, 500);
    }
};
