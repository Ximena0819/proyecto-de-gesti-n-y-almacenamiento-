import { verificarToken, NOMBRE_COOKIE_TOKEN } from "../utils/jwt.js";

/**
 * Extrae el token de la cookie httpOnly "token" o, si no está presente,
 * del header "Authorization: Bearer <token>".
 */
function extraerToken(req) {
  const tokenCookie = req.cookies?.[NOMBRE_COOKIE_TOKEN];
  if (tokenCookie) return tokenCookie;

  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith("Bearer ")) {
    return authHeader.slice("Bearer ".length).trim();
  }

  return null;
}

/**
 * Middleware que protege una ruta: exige un JWT válido (login previo).
 * Si es válido, deja en `req.usuario` los datos del token (id, correo, cargo).
 */
export function protegerRuta(req, res, next) {
  const token = extraerToken(req);

  if (!token) {
    return res.status(401).json({ error: "No autenticado: se requiere iniciar sesión." });
  }

  try {
    const payload = verificarToken(token);
    req.usuario = payload;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Sesión inválida o expirada. Inicia sesión nuevamente." });
  }
}

/**
 * Middleware que además exige que el usuario autenticado tenga uno de los
 * cargos indicados (control de acceso por rol).
 * Uso: router.delete("/:id", protegerRuta, permitirCargos("RECTOR", "COORDINADOR"), controlador)
 */
export function permitirCargos(...cargosPermitidos) {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.status(401).json({ error: "No autenticado: se requiere iniciar sesión." });
    }
    if (!cargosPermitidos.includes(req.usuario.cargo)) {
      return res.status(403).json({ error: "No tienes permisos para realizar esta acción." });
    }
    next();
  };
}
