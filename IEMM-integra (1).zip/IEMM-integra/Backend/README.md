# API de Inventario - I.E.M.M

API REST para el control de implementos (inventario) de la institución, construida con **Express**, **Prisma ORM** y **PostgreSQL**.

## Requisitos

- Node.js 20.19 o superior
- Una base de datos PostgreSQL (local o en la nube)

## Instalación

1. Instala las dependencias:

   ```bash
   npm install
   ```

2. Crea tu archivo de variables de entorno copiando el ejemplo:

   ```bash
   cp .env.example .env
   ```

   Edita `.env` y coloca tu cadena de conexión real:

   ```
   DATABASE_URL="postgresql://usuario:contraseña@localhost:5432/nombre_base_datos"
   ```

3. Aplica las migraciones a la base de datos (esto crea todas las tablas):

   ```bash
   npx prisma migrate deploy
   ```

4. Genera el cliente de Prisma:

   ```bash
   npx prisma generate
   ```

## Ejecución

```bash
npm run dev     
```

El servidor queda disponible en `http://localhost:3000` (o el puerto indicado en `PORT`).

## Autenticación

- `POST /auth/login` — body `{ "correo", "contraseña" }`. Devuelve el usuario (sin contraseña) y un JWT, tanto en una cookie `httpOnly` como en el cuerpo de la respuesta (`token`).
- `GET /auth/me` — requiere sesión. Devuelve los datos del usuario autenticado.
- `POST /auth/signout` — limpia la cookie de sesión.

El token se puede enviar de dos formas (ambas soportadas por el middleware):

- Cookie `httpOnly` `token` (la que pone `/auth/login` automáticamente; requiere `credentials: "include"` en `fetch`/axios desde el navegador).
- Header `Authorization: Bearer <token>` (útil para Postman, apps móviles, etc.).

### Primer usuario (bootstrap)

Como todas las rutas quedan protegidas, no es posible crear el primer usuario vía API. Ejecuta:

```bash
npm run seed
```

Esto crea (o actualiza) un usuario administrador con cargo `RECTOR` usando las variables `SEED_ADMIN_CORREO`, `SEED_ADMIN_CONTRASENA` y `SEED_ADMIN_DOCUMENTO` del `.env` (o los valores por defecto si no están definidas). **Cambia esa contraseña después del primer login.**

## Endpoints disponibles

Todos siguen el mismo patrón CRUD (`GET`, `POST`, `PUT /:id`, `DELETE /:id`) y **requieren estar autenticado** (JWT válido, ver sección de Autenticación):

- `/usuario`
- `/ubicacion`
- `/responsable`
- `/proveedor`
- `/implemento`
- `/categoria`

## Notas técnicas

- CORS está habilitado con `credentials: true` (refleja el origen de la petición) para que un frontend en otro origen pueda consumir la API y enviar/recibir la cookie de sesión.
- Los errores de base de datos (duplicados, registros no encontrados, relaciones en uso) se traducen a mensajes claros en español con el código HTTP correspondiente; cualquier otro error no reconocido se registra en el servidor pero no expone su detalle interno al cliente.
- El campo `contraseña` de `Usuario` se guarda hasheado con `bcryptjs` (10 rondas de sal) y nunca se incluye en las respuestas de la API (`POST/GET/PUT /usuario`, `/auth/login`, `/auth/me`).
- Variables de entorno nuevas: `JWT_SECRET` (obligatoria, firma los tokens), `JWT_EXPIRES_IN` (opcional, por defecto `8h`), y `SEED_ADMIN_*` (opcionales, usadas solo por `npm run seed`).
